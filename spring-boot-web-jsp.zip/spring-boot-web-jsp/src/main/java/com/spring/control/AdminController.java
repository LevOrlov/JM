package com.spring.control;


import com.spring.model.User;
import com.spring.service.UserServiсe;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;


@Controller
public class AdminController {

    @Autowired
    private UserServiсe UserServiceImpl;

    @RequestMapping(value = "/", method = RequestMethod.GET)
    public String notesList(Model model) {
        model.addAttribute("notesList", UserServiceImpl.getAllUsers());
        model.addAttribute("addUserObject", new User());
        return "thumhome";
    }

    @RequestMapping(value = "/admin/edit", method = RequestMethod.POST)
    public String edit(@ModelAttribute User user) {
        User temp_user = UserServiceImpl.getUserById(user.getId());
        temp_user.setName(user.getName());
        temp_user.setLogin(user.getLogin());
        temp_user.setPassword(user.getPassword());
        UserServiceImpl.updateUser(temp_user);
        return "redirect:/";
    }

    @RequestMapping(value = "/logout")
    public String logout(HttpServletRequest request) {
        System.out.println("logout()");
        HttpSession httpSession = request.getSession();
        httpSession.invalidate();
        return "redirect:/";
    }

    @RequestMapping(value = "/admin/delete/{id}", method = RequestMethod.GET)
    public String deleteContact(@PathVariable(required = false, name = "id") int id) {
        UserServiceImpl.deleteUser(id);
        return "redirect:/";
    }

    @RequestMapping(value = "/admin/add", method = RequestMethod.POST)
    public String addModal(@ModelAttribute(value = "user") User user) {
        UserServiceImpl.addUser(user);
        return "redirect:/";
    }








	/*@RequestMapping(value  = "/admin/add", method = RequestMethod.POST)
	public String addComplete(User user) {
		UserServiceImpl.addUser(user);
		return "redirect:/";
	}*/

	/*
	@RequestMapping(value={"/admin/edit","/admin/edit/{id}"}, method = RequestMethod.GET)
	public String edit(Model model, @PathVariable(required = false, name = "id") int id) {
		model.addAttribute("user", UserServiceImpl.getUserById(id));
		return "notesEdit";
	}*/
	/*
	@RequestMapping(value  = "/admin/edit", method = RequestMethod.POST)
	public String Edit(User user) {
		//<input type="hidden" class="form-control" th:field="*{id}"/>
		//почему без этого id не передается7
		System.out.println(user.getId());
		UserServiceImpl.updateUser(user);
		return "redirect:/";
	}
	*/
	/*

	@RequestMapping(value={"/admin/add"}, method = RequestMethod.GET)
	public String add(Model model) {
		User user = new User();
		model.addAttribute("user", user);
		return "add";
	}*/
}
